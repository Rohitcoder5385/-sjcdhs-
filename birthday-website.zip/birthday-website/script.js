/* =========================================================
   🎂 Maahi's Birthday World — script.js
   Everything is plain JavaScript (no libraries, works offline).
   EDIT THE CONFIG BELOW to change photos, videos, captions, music.
   ========================================================= */
const CONFIG = {
  // Your song (put the file in assets/music/).
  musicFile: "assets/music/music.mp3",   // "" = built-in music-box tune
  musicStart: 14,           // seconds to skip at the start of the song
  // MEMORY MOMENTS: each inner list is shown in the gap AFTER that page (1st list: after page 1, 2nd: after page 2 ...).
  // type: "image" or "video". Add / remove / reorder lines freely.
  memories: [
    [ { type: "image", src: "assets/images/photo1.jpg", cap: "Elegant & effortless ✨" },
      { type: "video", src: "assets/videos/clip01.mp4", cap: "Moments that made us smile" },
      { type: "video", src: "assets/videos/clip02.mp4", cap: "Pure happiness 😊" } ],
    [ { type: "video", src: "assets/videos/clip03.mp4", cap: "Memories in motion" },
      { type: "image", src: "assets/images/photo2.jpg", cap: "Looking beautiful as always 💙" },
      { type: "video", src: "assets/videos/clip04.mp4", cap: "Laughs we'll never forget" } ],
    [ { type: "video", src: "assets/videos/clip05.mp4", cap: "Good vibes only" },
      { type: "video", src: "assets/videos/clip06.mp4", cap: "Just being us" },
      { type: "video", src: "assets/videos/clip07.mp4", cap: "Little moments, big memories" } ],
    [ { type: "image", src: "assets/images/photo3.jpg", cap: "Sunshine in human form ☀️" },
      { type: "video", src: "assets/videos/clip08.mp4", cap: "Fun times 🎉" },
      { type: "video", src: "assets/videos/clip09.mp4", cap: "Memories to cherish" } ],
    [ { type: "video", src: "assets/videos/clip10.mp4", cap: "Happy days" },
      { type: "video", src: "assets/videos/clip11.mp4", cap: "Smiles all around" } ],
    [ { type: "video", src: "assets/videos/clip12.mp4", cap: "More memories ❤️" },
      { type: "video", src: "assets/videos/clip13.mp4", cap: "Here's to many more" } ]
  ]
};

const $ = id => document.getElementById(id);
const rnd = (a, b) => a + Math.random() * (b - a);
const wait = ms => new Promise(r => setTimeout(r, ms));
const show = el => el.classList.remove('hidden');
const hide = el => el.classList.add('hidden');

/* ---------------- AUDIO (synthesised: no files needed) ---------------- */
let ac, master, musicOn = false, musicStarted = false, bgFile = null, melodyTimer;
function audioInit() {
  if (ac) { if (ac.state === 'suspended') ac.resume(); return; }
  try {
    ac = new (window.AudioContext || window.webkitAudioContext)();
    master = ac.createGain(); master.gain.value = 0; master.connect(ac.destination);
  } catch (e) { ac = null; }
}
function tone(f, dur = .3, type = 'sine', vol = .2, when = 0, dest) {
  if (!ac) return;
  const t = ac.currentTime + when, o = ac.createOscillator(), g = ac.createGain();
  o.type = type; o.frequency.setValueAtTime(f, t);
  g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(vol, t + .02);
  g.gain.exponentialRampToValueAtTime(.0001, t + dur);
  o.connect(g); g.connect(dest || ac.destination); o.start(t); o.stop(t + dur + .05);
}
function noise(dur, vol, type, f0, f1) {
  if (!ac) return;
  const n = ac.sampleRate * dur, b = ac.createBuffer(1, n, ac.sampleRate), d = b.getChannelData(0);
  for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1;
  const s = ac.createBufferSource(); s.buffer = b;
  const fl = ac.createBiquadFilter(); fl.type = type; fl.frequency.setValueAtTime(f0, ac.currentTime);
  fl.frequency.exponentialRampToValueAtTime(f1, ac.currentTime + dur);
  const g = ac.createGain(); g.gain.setValueAtTime(vol, ac.currentTime);
  g.gain.exponentialRampToValueAtTime(.001, ac.currentTime + dur);
  s.connect(fl); fl.connect(g); g.connect(ac.destination); s.start();
}
const sfx = {
  click() { tone(880, .12, 'sine', .08) },
  pop() { noise(.14, .9, 'highpass', 1500, 600); tone(220, .12, 'triangle', .3) },
  blow() { noise(1, .5, 'lowpass', 900, 200) },
  swish() { noise(.45, .6, 'bandpass', 2500, 700); tone(120, .25, 'sawtooth', .12, .35) },
  chime() { [1046, 1318, 1568, 2093].forEach((f, i) => tone(f, .9, 'sine', .12, i * .12)) },
  open() { noise(.5, .25, 'bandpass', 400, 3000); sfx.chime() }
};
// Happy-Birthday music box (public-domain tune)
const TUNE = [[67,.75],[67,.25],[69,1],[67,1],[72,1],[71,2],[67,.75],[67,.25],[69,1],[67,1],[74,1],[72,2],
  [67,.75],[67,.25],[79,1],[76,1],[72,1],[71,1],[69,1],[77,.75],[77,.25],[76,1],[72,1],[74,1],[72,2]];
function playTune() {
  if (!ac) return;
  let t = 0; const B = .62;
  TUNE.forEach(([m, d]) => { const f = 440 * Math.pow(2, (m - 69) / 12);
    tone(f, d * B * 1.8, 'triangle', .22, t, master); tone(f * 2, d * B, 'sine', .05, t, master); t += d * B; });
  melodyTimer = setTimeout(playTune, (t + 2) * 1000);
}
function startMusic() {
  if (musicStarted) return; musicStarted = true; musicOn = true;
  const synth = () => { bgFile = null; playTune(); setVol(); };
  if (CONFIG.musicFile) {
    bgFile = new Audio(CONFIG.musicFile); bgFile.preload = 'auto'; bgFile.volume = .6;
    const seek = () => { try { if (bgFile.currentTime < CONFIG.musicStart) bgFile.currentTime = CONFIG.musicStart; } catch (e) {} };
    seek(); bgFile.addEventListener('loadedmetadata', seek);
    bgFile.addEventListener('ended', () => { bgFile.currentTime = CONFIG.musicStart; bgFile.play().catch(() => {}); });
    bgFile.onerror = synth; bgFile.play().catch(synth);
  } else synth();
  setVol();
}
function setVol(duck) {
  const v = musicOn ? (duck ? .1 : .6) : 0;
  if (master) master.gain.setTargetAtTime(v, ac.currentTime, .15);
  if (bgFile) { bgFile.volume = v; if (musicOn) { bgFile.paused && bgFile.play().catch(() => {}); } else bgFile.pause(); }
  $('musicBtn').textContent = musicOn ? '🔊' : '🔇';
}
$('musicBtn').onclick = () => { audioInit(); if (!musicStarted) startMusic(); else { musicOn = !musicOn; setVol(); } };
document.addEventListener('visibilitychange', () => { if (ac) document.hidden ? ac.suspend() : ac.resume(); if (bgFile) { if (document.hidden) bgFile.pause(); else if (musicOn) bgFile.play().catch(() => {}); } });

/* ---------------- PARTICLES (confetti, sparkles, fireworks) ---------------- */
const fx = $('fx'), fc = fx.getContext('2d'); let W, H, DPR = Math.min(devicePixelRatio || 1, innerWidth < 700 ? 1.5 : 2), P = [], running = false;
function size() { W = innerWidth; H = innerHeight; fx.width = W * DPR; fx.height = H * DPR; fc.setTransform(DPR, 0, 0, DPR, 0, 0); }
size(); addEventListener('resize', size);
const COLORS = ['#ffd27a', '#ff6fa8', '#b48aff', '#ffffff', '#ff9a5a', '#7ad7ff'];
function add(p) { if (P.length < (innerWidth < 700 ? 450 : 900)) P.push(p); if (!running) { running = true; requestAnimationFrame(loop); } }
function confetti(x, y, n = 60, power = 9, angle = -Math.PI / 2, spread = Math.PI * 2) {
  for (let i = 0; i < n; i++) { const a = angle + rnd(-spread / 2, spread / 2), s = rnd(2, power);
    add({ t: 'c', x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, g: .18, d: .985, r: rnd(0, 6), vr: rnd(-.3, .3), w: rnd(6, 11), h: rnd(4, 7), c: COLORS[i % COLORS.length], l: rnd(120, 220) }); }
}
function rain(n = 80) { for (let i = 0; i < n; i++) setTimeout(() => add({ t: 'c', x: rnd(0, W), y: -10, vx: rnd(-1, 1), vy: rnd(2, 5), g: .02, d: 1, r: 0, vr: rnd(-.2, .2), w: 8, h: 5, c: COLORS[i % 6], l: 400 }), i * 25); }
function cannon() { confetti(0, H, 90, 20, -Math.PI / 3, .8); confetti(W, H, 90, 20, -2 * Math.PI / 3, .8); sfx.pop(); }
function sparkle(x, y, n = 14) { for (let i = 0; i < n; i++) add({ t: 's', x, y, vx: rnd(-2.5, 2.5), vy: rnd(-3, 1.5), g: .05, d: .97, s: rnd(1.5, 3.5), c: '#ffe3a0', l: rnd(30, 60) }); }
function firework(x, y) {
  const h = rnd(0, 360);
  for (let i = 0; i < 70; i++) { const a = Math.PI * 2 * i / 70, s = rnd(1.5, 5.5);
    add({ t: 'f', x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, g: .05, d: .965, s: 2.2, c: `hsl(${h + rnd(-25, 25)},100%,65%)`, l: rnd(60, 95) }); }
  noise(.5, .25, 'lowpass', 1500, 100);
}
function loop() {
  fc.clearRect(0, 0, W, H);
  P = P.filter(p => {
    p.vx *= p.d; p.vy = p.vy * p.d + p.g; p.x += p.vx; p.y += p.vy; p.l--;
    if (p.l <= 0 || p.y > H + 30) return false;
    if (p.t === 'c') { p.r += p.vr; fc.save(); fc.translate(p.x, p.y); fc.rotate(p.r); fc.fillStyle = p.c; fc.fillRect(-p.w / 2, -p.h / 2, p.w, p.h * Math.abs(Math.cos(p.r * 2) + .3)); fc.restore(); }
    else { fc.globalAlpha = Math.min(1, p.l / 30); fc.fillStyle = p.c; fc.shadowColor = p.c; fc.shadowBlur = 10; fc.beginPath(); fc.arc(p.x, p.y, p.s, 0, 7); fc.fill(); fc.shadowBlur = 0; fc.globalAlpha = 1; }
    return true;
  });
  P.length ? requestAnimationFrame(loop) : (running = false, fc.clearRect(0, 0, W, H));
}
addEventListener('pointerdown', e => sparkle(e.clientX, e.clientY, 8));

/* ---------------- FAIRY LIGHTS + FLOATING HEARTS ---------------- */
document.querySelectorAll('.fairy').forEach(f => {
  const n = Math.floor(innerWidth / 34);
  for (let i = 0; i < n; i++) { const b = document.createElement('i'), fr = i / (n - 1);
    b.style.left = (fr * 98 + 1) + '%'; b.style.top = (8 + 20 * Math.abs(Math.sin(fr * Math.PI * 3))) + 'px';
    b.style.animationDelay = rnd(0, 2) + 's'; f.appendChild(b); }
});
$('fairy').classList.add('seq');
function floaty(emoji, size) {
  const s = document.createElement('span'); s.className = 'floaty'; s.textContent = emoji;
  s.style.cssText = `left:${rnd(0, 95)}%;font-size:${size || rnd(16, 34)}px;animation-duration:${rnd(7, 12)}s;--dx:${rnd(-60, 60)}px;opacity:${rnd(.5, .9)}`;
  document.body.appendChild(s); setTimeout(() => s.remove(), 12500);
}
setInterval(() => { if (document.hidden) return; if (cur === 5 || cur === 7 || (cur === 0 && lit)) floaty(['❤️', '💖', '✨', '💜'][Math.floor(rnd(0, 4))]); if (cur === 7) floaty('🎈', rnd(30, 50)); }, 800);

/* ---------------- PAGE NAVIGATION ---------------- */
const pages = [...document.querySelectorAll('.page')]; let cur = 0, lit = false;
const hooks = { 3: buildCake2, 7: finale };
function go(n) {
  if (n >= pages.length) return; pages[cur].classList.remove('active'); cur = n; pages[n].classList.add('active');
  sfx.chime(); setVol(); hooks[n] && setTimeout(hooks[n], 700);
}
document.querySelectorAll('[data-next]').forEach(b => b.addEventListener('click', () => proceed(pages.indexOf(b.closest('.page')))));

/* ---------------- PAGE 1 : TURN ON THE LIGHTS ---------------- */
$('lightsBtn').onclick = async () => {
  audioInit(); startMusic(); sfx.click(); hide($('lightsBtn')); lit = true;
  document.body.classList.remove('dark'); document.body.classList.add('lit');
  const deco = $('deco1');
  for (let i = 0; i < 3; i++) { const l = document.createElement('div');
    l.style.cssText = `position:absolute;width:70vmax;height:70vmax;left:${[-20, 30, 60][i]}%;top:${[-30, -20, -35][i]}%;background:radial-gradient(circle,rgba(255,190,120,.28),transparent 65%);opacity:0;transition:opacity 1.6s`;
    deco.appendChild(l); setTimeout(() => l.style.opacity = 1, 400 + i * 700); sfx.click(); }
  document.querySelectorAll('#fairy i').forEach((b, i) => setTimeout(() => b.classList.add('on'), 800 + i * 60));
  await wait(1800);
  const cols = ['#ff6fa8', '#b48aff', '#ffd27a', '#ff5a7a', '#7ad7ff'];
  for (let i = 0; i < 9; i++) { const b = document.createElement('div'); b.className = 'balloon-bg';
    b.style.cssText = `left:${4 + i * 11}%;top:${rnd(55, 80)}%;background:radial-gradient(circle at 30% 28%,#fff,${cols[i % 5]} 20%,${cols[i % 5]}aa);animation-delay:${rnd(0, 3)}s;box-shadow:0 0 30px ${cols[i % 5]}77`;
    deco.appendChild(b); }
  ['🎀', '🎉', '🎊', '🎁', '🪩'].forEach((e, i) => { const b = document.createElement('b'); b.textContent = e;
    b.style.cssText = `left:${10 + i * 20}%;top:${i % 2 ? 22 : 12}%;animation-delay:${i * .6}s`; deco.appendChild(b); });
  rain(120); await wait(2600); show($('p1msg'));
};

/* ---------------- PAGE 2 : BALLOONS ---------------- */
const WORDS = ['You', 'Are', 'Too', 'Special ❤️']; let popped = 0, popT;
[['#ff6fa8', '#c2185b', 4, 30], ['#b48aff', '#6a2fe0', 28, 50], ['#ffd27a', '#e08a00', 52, 28], ['#ff5a7a', '#b3123f', 74, 52]].forEach(([c, d, l, t], i) => {
  const b = document.createElement('div'); b.className = 'balloon'; b.style.cssText = `--c:${c};--d:${d};left:${l}%;top:${t}%;animation-delay:${i * .7}s`;
  b.onclick = () => {
    if (b.classList.contains('pop')) return; const word = WORDS[popped]; sfx.pop(); const r = b.getBoundingClientRect();
    confetti(r.left + r.width / 2, r.top + r.height / 2, 40, 7); b.classList.add('pop');
    $('popWord').textContent = word; $('popWord').style.animation = 'none'; void $('popWord').offsetWidth; $('popWord').style.animation = '';
    show($('popMsg')); clearTimeout(popT); popped++;
    const w = document.createElement('span'); w.textContent = word; $('trail').appendChild(w);
    popT = setTimeout(() => { hide($('popMsg')); if (popped === 4) { hide($('trail')); hide($('popHint')); show($('p2end')); confetti(W / 2, H / 2, 100, 12); } }, 1700);
  };
  $('balloons').appendChild(b);
});

/* ---------------- PAGE 3 : CANDLES ---------------- */
let out = 0; const CAN = 5;
for (let i = 0; i < CAN; i++) { const c = document.createElement('div'); c.className = 'candle'; c.innerHTML = '<div class="flame"></div>'; c.onclick = () => blowOne(c); $('candles').appendChild(c); }
function blowOne(c) {
  if (c.classList.contains('out')) return; c.classList.add('out'); out++;
  for (let i = 0; i < 4; i++) setTimeout(() => { const s = document.createElement('div'); s.className = 'smoke'; s.style.marginLeft = rnd(-6, 6) + 'px'; c.appendChild(s); setTimeout(() => s.remove(), 3000); }, i * 250);
  if (out === CAN) setTimeout(wishDone, 1200);
}
function blowAll() { sfx.blow(); document.querySelectorAll('.candle').forEach((c, i) => setTimeout(() => blowOne(c), i * 160)); stopMic(); }
function wishDone() {
  $('dim').classList.add('on'); $('cake1').classList.add('after'); hide($('blowRow')); $('wishHint').textContent = '✨ Wish made ✨';
  setTimeout(() => { show($('wishMsg')); sparkle(W / 2, H / 2, 40); }, 1200);
}
$('blowBtn').onclick = blowAll;
$('cake1').addEventListener('click', e => { if (!e.target.closest('.candle')) blowAll(); });
let micStream, micRAF, micCtx;
function stopMic() { cancelAnimationFrame(micRAF); micStream && micStream.getTracks().forEach(t => t.stop()); micStream = null; try { micCtx && micCtx.close(); } catch (e) {} micCtx = null; }
$('micBtn').onclick = async () => {
  const btn = $('micBtn');
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) { btn.textContent = '🎤 Not available here, tap the cake!'; return; }
  try {
    const AC = window.AudioContext || window.webkitAudioContext; micCtx = new AC(); micCtx.resume();
    micStream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false } });
    await micCtx.resume(); const an = micCtx.createAnalyser(); an.fftSize = 512;
    micCtx.createMediaStreamSource(micStream).connect(an); const buf = new Uint8Array(an.fftSize);
    let hot = 0, n = 0, base = 0; btn.textContent = '🎤 Listening... blow now!';
    const tick = () => {
      an.getByteTimeDomainData(buf); let s = 0; for (const v of buf) s += (v - 128) * (v - 128); const lvl = Math.sqrt(s / buf.length) / 128;
      if (n < 25) { base = Math.max(base, lvl); n++; } else { hot = lvl > Math.max(base * 2.5, base + .07) ? hot + 1 : 0; if (hot > 4) { blowAll(); return; } }
      micRAF = requestAnimationFrame(tick); };
    tick();
  } catch (e) { stopMic(); btn.textContent = '🎤 Mic blocked, tap the cake instead!'; }
};

/* ---------------- PAGE 4 : CUT THE CAKE ---------------- */
let cakeBuilt = false, cutDone = false;
function buildCake2() {
  if (cakeBuilt) return; cakeBuilt = true;
  $('cake2').innerHTML = '<div class="plate"></div><div class="tier t1"><i class="drip"></i></div><div class="tier t2"><i class="drip"></i></div><div class="tier t3"><i class="drip"></i></div>';
}
const st = $('cutStage'), cv = $('cutLine'), cx = cv.getContext('2d'); let pts = [], drawing = false;
function rel(e) { const r = st.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; }
function drawLine() {
  const r = st.getBoundingClientRect(); cv.width = r.width * DPR; cv.height = r.height * DPR; cx.setTransform(DPR, 0, 0, DPR, 0, 0);
  if (pts.length < 2) return; cx.lineCap = 'round'; cx.lineJoin = 'round';
  cx.beginPath(); pts.forEach((p, i) => i ? cx.lineTo(p.x, p.y) : cx.moveTo(p.x, p.y));
  cx.strokeStyle = '#ffd27a'; cx.lineWidth = 7; cx.shadowColor = '#ffb347'; cx.shadowBlur = 18; cx.stroke();
  cx.strokeStyle = '#fff'; cx.lineWidth = 2.5; cx.shadowBlur = 0; cx.stroke();
  const l = pts[pts.length - 1]; cx.font = '28px serif'; cx.fillText('🔪', l.x - 6, l.y + 8);
}
st.addEventListener('pointerdown', e => { if (cutDone) return; drawing = true; pts = [rel(e)]; st.setPointerCapture(e.pointerId); });
st.addEventListener('pointermove', e => { if (!drawing) return; pts.push(rel(e)); drawLine(); });
const endCut = e => {
  if (!drawing) return; drawing = false; const a = pts[0], b = pts[pts.length - 1];
  const cr = $('cake2').getBoundingClientRect(), sr = st.getBoundingClientRect(), ox = cr.left - sr.left, oy = cr.top - sr.top;
  const len = a && b ? Math.hypot(b.x - a.x, b.y - a.y) : 0, mx = (a.x + b.x) / 2 - ox, my = (a.y + b.y) / 2 - oy;
  if (len > cr.width * .55 && mx > 0 && mx < cr.width && my > 0 && my < cr.height) doCut({ x: a.x - ox, y: a.y - oy }, { x: b.x - ox, y: b.y - oy });
  else { pts = []; drawLine(); $('cutHint').innerHTML = 'Almost! Swipe all the way across the cake 🔪'; }
};
st.addEventListener('pointerup', endCut); st.addEventListener('pointercancel', endCut);
function doCut(a, b) {
  cutDone = true; sfx.swish();
  const L = Math.hypot(b.x - a.x, b.y - a.y), dx = (b.x - a.x) / L, dy = (b.y - a.y) / L, nx = -dy, ny = dx, K = 3000;
  const p = (x, y) => `${x}px ${y}px`, A = [a.x - dx * K, a.y - dy * K], B = [a.x + dx * K, a.y + dy * K];
  const poly = s => `polygon(${p(...A)},${p(...B)},${p(B[0] + nx * K * s, B[1] + ny * K * s)},${p(A[0] + nx * K * s, A[1] + ny * K * s)})`;
  const cake = $('cake2'), html = cake.innerHTML; cake.innerHTML = '';
  const mk = cls => { const d = document.createElement('div'); d.className = 'half ' + cls; d.innerHTML = html; cake.appendChild(d); return d; };
  mk('inside'); const h1 = mk(''), h2 = mk(''); h1.style.clipPath = poly(1); h2.style.clipPath = poly(-1);
  setTimeout(() => { h1.style.transform = `translate(${nx * 38}px,${ny * 38}px) rotate(${3}deg)`; h2.style.transform = `translate(${-nx * 38}px,${-ny * 38}px) rotate(${-3}deg)`; }, 250);
  setTimeout(() => { pts = []; drawLine(); }, 500);
  const r = cake.getBoundingClientRect(); setTimeout(() => { confetti(r.left + r.width / 2, r.top + r.height / 3, 120, 14); cannon(); sfx.chime(); }, 700);
  $('cutHint').innerHTML = 'Perfect cut! 🎂'; setTimeout(() => { st.classList.add('after'); show($('cutMsg')); }, 2200);
}

/* ---------------- PAGE 5 : GIFT ---------------- */
let giftOpen = false;
$('gift').onclick = () => {
  if (giftOpen) return; giftOpen = true; $('gift').classList.add('open'); sfx.open(); hide($('giftHint'));
  const r = $('gift').getBoundingClientRect(); sparkle(r.left + r.width / 2, r.top + 40, 60); confetti(r.left + r.width / 2, r.top + 40, 70, 11);
  setTimeout(() => show($('giftLetter')), 1500);
};

/* ---------------- PAGE 6 : ENVELOPE ---------------- */
let envOpen = false;
$('env').onclick = e => {
  if (envOpen || e.target.closest('[contenteditable]')) return; envOpen = true; sfx.open(); hide($('envHint'));
  $('env').classList.add('open'); sparkle(W / 2, H / 2, 30);
  setTimeout(() => { $('env').style.filter = 'none'; $('env').classList.add('read'); show($('p6btns')); }, 1700);
};
hide($('p6btns'));
$('secretBtn').onclick = () => { sfx.chime(); const m = $('secretMsg'); m.classList.contains('hidden') ? show(m) : hide(m); sparkle(W / 2, H - 120, 30); };

/* ---------------- MEMORY MOMENTS (photos & videos between pages) ---------------- */
const seenGap = {};
function proceed(i) {
  const list = CONFIG.memories[i];
  if (!list || !list.length || seenGap[i]) return go(i + 1);
  seenGap[i] = true; let k = 0; show($('mem'));
  const render = () => {
    const m = list[k], fr = $('memFrame'); fr.style.setProperty('--r', (k % 2 ? 1.4 : -1.4) + 'deg');
    fr.innerHTML = m.type === 'video' ? `<video src="${m.src}" autoplay muted loop playsinline></video>` : `<img src="${m.src}" alt="">`;
    const v = fr.querySelector('video'); setVol(); if (v) { fr.onclick = () => v.paused ? v.play() : v.pause(); } else fr.onclick = null;
    $('memCap').textContent = m.cap; $('memTitle').textContent = `A little memory 📸  ${k + 1}/${list.length}`;
    $('memNext').textContent = k === list.length - 1 ? 'Continue →' : 'Next →'; sparkle(W / 2, H / 2, 16); sfx.chime();
  };
  $('memNext').onclick = () => {
    $('memFrame').innerHTML = ''; k++;
    if (k < list.length) return render();
    hide($('mem')); setVol(); go(i + 1);
  };
  render();
}

/* ---------------- PARTY PAGE : the "No" button runs away ---------------- */
const yes = $('yesBtn'), no = $('noBtn'); let tries = 0, lastDodge = 0, phAdded = false;
const TEASE = ['Nice try 😜', 'Too slow! 🏃‍♀️', "Hehe, can't catch me 😝", 'Just say yes 🥳', 'The button is shy 🙈', 'Wrong button 😂', 'Last chance... say YES!', 'It will run forever 😎'];
const hit = (a, b, m) => !(a.right + m < b.left || a.left - m > b.right || a.bottom + m < b.top || a.top - m > b.bottom);
function dodge(e) {
  if (e && e.cancelable) e.preventDefault();
  const now = Date.now(); if (now - lastDodge < 180) return; lastDodge = now; tries++;
  const w = no.offsetWidth, h = no.offsetHeight;
  if (!phAdded) { phAdded = true; const ph = document.createElement('span'); ph.style.cssText = `width:${w}px;height:${h}px`; no.parentNode.insertBefore(ph, no); no.style.position = 'fixed'; const r = no.getBoundingClientRect(); }
  const avoid = [yes, $('partyQ'), $('partyHint'), $('noTease')].map(x => x.getBoundingClientRect());
  const cur = no.getBoundingClientRect(), px = e && e.clientX, py = e && e.clientY; let x, y;
  for (let k = 0; k < 60; k++) {
    x = rnd(10, innerWidth - w - 10); y = rnd(70, innerHeight - h - 10);
    const r = { left: x, right: x + w, top: y, bottom: y + h };
    if (avoid.some(a => hit(r, a, 8))) continue;
    if (Math.hypot(x - cur.left, y - cur.top) < 100) continue;
    if (px !== undefined && Math.hypot(x + w / 2 - px, y + h / 2 - py) < 110) continue; break;
  }
  no.style.left = x + 'px'; no.style.top = y + 'px'; sfx.click();
  $('noTease').textContent = TEASE[(tries - 1) % TEASE.length];
  yes.style.transform = `scale(${Math.min(1 + tries * .06, 1.6)})`;
}
['pointerenter', 'pointerdown', 'click'].forEach(ev => no.addEventListener(ev, dodge));
no.addEventListener('touchstart', dodge, { passive: false });
document.addEventListener('pointermove', e => { if (e.pointerType !== 'mouse' || !pages[cur] || pages[cur].id !== 'pParty' || $('partyOn').classList.contains('hidden') === false) return;
  const r = no.getBoundingClientRect(); if (Math.hypot(e.clientX - (r.left + r.width / 2), e.clientY - (r.top + r.height / 2)) < 90) dodge(e); });
yes.onclick = () => {
  sfx.open(); const pg = $('pParty'); pg.classList.add('party'); ['yesno', 'partyQ', 'partyHint', 'noTease'].forEach(id => hide($(id))); hide(no);
  show($('partyOn')); cannon(); let n = 0;
  const t = setInterval(() => { cannon(); firework(rnd(W * .15, W * .85), rnd(H * .1, H * .45)); if (++n > 6) clearInterval(t); }, 900);
};

/* ---------------- PAGE 8 : FINAL SURPRISE ---------------- */
const COMPLIMENTS = ['You light up every room you walk into ✨', 'Your smile is contagious 😊', 'You are kind in a way that\'s rare 🌸', 'You make ordinary days feel special ❤️', 'You are stronger than you think 💪', 'The world is better with you in it 🌍', 'Pure sunshine, that\'s you ☀️', 'You deserve every good thing coming your way 🌟'];
const sky = $('stars');
for (let i = 0; i < 80; i++) { const s = document.createElement('i'); s.className = 'star'; s.style.cssText = `left:${rnd(0, 100)}%;top:${rnd(0, 100)}%;--s:${rnd(1, 3)}px;--t:${rnd(1.5, 4)}s;animation-delay:${rnd(0, 3)}s`; s.style.pointerEvents = 'none'; sky.appendChild(s); }
COMPLIMENTS.forEach((c, i) => { const s = document.createElement('i'); s.className = 'star big'; s.style.cssText = `left:${6 + (i % 4) * 25 + rnd(0, 8)}%;top:${i < 4 ? rnd(4, 14) : rnd(84, 94)}%;--t:${rnd(1.5, 3)}s`;
  s.onclick = ev => { ev.stopPropagation(); sfx.chime(); const t = $('starMsg'); t.textContent = c; show(t); sparkle(ev.clientX, ev.clientY, 30); clearTimeout(t.h); t.h = setTimeout(() => hide(t), 3000); };
  sky.appendChild(s); });
['photo1', 'photo3', 'photo2'].forEach((p, i) => { const im = document.createElement('img'); im.src = `assets/images/${p}.jpg`; im.alt = ''; im.style.setProperty('--r', [-4, 3, -2][i] + 'deg'); im.style.animationDelay = i * .8 + 's'; $('strip').appendChild(im); });
const FINAL = `Today is all about you.

I hope you always find happiness in the smallest things, courage in difficult moments, and countless reasons to smile.

Keep shining, keep laughing, and keep being the wonderful person you are.

You deserve all the happiness in this world.

And remember, somewhere out there, there's a friend who genuinely wishes the very best for you.

Lots of love and best wishes! ❤️`;
let finaleStarted = false;
async function finale() {
  if (finaleStarted) return; finaleStarted = true;
  for (let i = 0; i < 12; i++) setTimeout(() => firework(rnd(W * .1, W * .9), rnd(H * .1, H * .5)), i * 650);
  cannon(); await wait(3500);
  const el = $('typed'); for (const ch of FINAL) { el.textContent += ch; await wait(ch === '\n' ? 280 : 42); }
  el.classList.add('done'); show($('made')); show($('finalBtns')); firework(W / 2, H / 3); sfx.chime();
  $('finalBtns').scrollIntoView({ behavior: 'smooth', block: 'center' });
}
hide($('made')); hide($('finalBtns'));
$('cannonBtn').onclick = () => { cannon(); firework(rnd(W * .2, W * .8), rnd(H * .1, H * .4)); };
$('replayBtn').onclick = () => location.reload();
