# Maahi's Birthday World 🎂

## Run it
Just double-click `index.html` (Chrome / Edge / Safari). No install, no internet needed except the optional Google Fonts.
For the microphone "blow out candles" feature use a local server (browsers block the mic on file://):
    cd birthday-website && python3 -m http.server 8000   → open http://localhost:8000
(Tap-to-blow always works without it.) To share it with Maahi, upload the folder to Netlify / GitHub Pages / Vercel.

## Photos, videos, music
Memory photos/videos appear between the pages (list in `CONFIG.memories` at the top of `script.js`: file name + caption each).
Song: `assets/music/music.mp3` (starts 14 seconds in — change `musicStart`). Put new files in `assets/` and update the names in `script.js`.

## Edit the letters
The two letters (pages 5 and 6) are plain text in `index.html` — edit them there.
